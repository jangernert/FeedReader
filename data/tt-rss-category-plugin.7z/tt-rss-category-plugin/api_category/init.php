<?php
class Api_category extends Plugin {
	private $host;
	private $dbh;

	function about()
	{
		return array(1.0,
			"API plugin for FeedReader",
			"JeanLuc",
			true
			);
	}
	
	function api_version()
	{
		return 2;
	}
	
	function init($host)
	{
		$this->host = $host;
		$this->dbh = $host->get_dbh();
		$this->host->add_api_method("addCategory", $this);
		$this->host->add_api_method("removeCategory", $this);
	}
	
	function removeCategory()
	{
		$category_id = (int)db_escape_string($_REQUEST["category_id"]);
		if ($category_id != "")
		{
			$this->dbh->query("DELETE FROM ttrss_feed_categories WHERE id = '$category_id' AND owner_uid = ".$_SESSION["uid"]);
			ccache_remove($category_id, $_SESSION["uid"], true);
			return array(API::STATUS_OK);
		}
		else
		{
			return array(API::STATUS_ERR, array("error" => 'INCORRECT_USAGE'));
		}
	}
	
	function addCategory()
	{
		$caption = db_escape_string($_REQUEST["caption"]);
		if ($caption != "")
		{
			add_feed_category($caption);
			return array(API::STATUS_OK, get_feed_category($caption));
		}
		else
		{
			return array(API::STATUS_ERR, array("error" => 'INCORRECT_USAGE'));
		}
	}
}
?>
