<?php
class Api_labels extends Plugin {
	private $host;
	private $dbh;

	function about()
	{
		return array(1.0,
			"API plugin for FeedReader",
			"JeanLuc",
			true
			);
	}
	
	function api_version()
	{
		return 2;
	}
	
	function init($host)
	{
		$this->host = $host;
		$this->dbh = $host->get_dbh();
		$this->host->add_api_method("addLabel", $this);
		$this->host->add_api_method("removeLabel", $this);
	}
	
	function removeLabel()
	{
		$label_id = (int)db_escape_string($_REQUEST["label_id"]);
		if ($label_id != "")
		{
			label_remove(feed_to_label_id($label_id), $_SESSION["uid"]);
			return array(API::STATUS_OK);
		}
		else
		{
			return array(API::STATUS_ERR, array("error" => 'INCORRECT_USAGE'));
		}
	}
	
	function addLabel()
	{
		$caption = db_escape_string($_REQUEST["caption"]);
		if ($caption != "")
		{
			label_create($caption);
			$id = label_find_id($caption, $_SESSION["uid"]);
			return array(API::STATUS_OK, label_to_feed_id($id));
		}
		else
		{
			return array(API::STATUS_ERR, array("error" => 'INCORRECT_USAGE'));
		}
	}
}
?>
